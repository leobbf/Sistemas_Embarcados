#!/bin/bash

echo Descompactar e excluir compactado 
tar -zxvf /home/pi/pac.tar
echo arquivo descompactado
rm /home/pi/pac.tar
echo pac excluido
echo
