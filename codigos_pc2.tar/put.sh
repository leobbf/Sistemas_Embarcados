#!/bin/bash

echo upload de arquivos  
echo
echo compactando pasta
tar -zcf pac.tar Skullpi
echo
echo pasta compactada
echo
echo conectando ao rasp
sshpass -p "leonard7" scp pac.tar pi@192.168.42.1:/home/pi
echo upload feito com sucesso
echo apagando pac.tar
rm pac.tar
echo flush na Skullpi
rm -r Skullpi
mkdir Skullpi
echo
