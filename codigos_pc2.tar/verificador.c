#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <pthread.h>
#include <signal.h>
#include <time.h>

int fd;

void tratamento_sinal(){

	puts("Fechando programa...");
	close(fd);
	exit(0);
} 

int main(){

	char bff[8];

	signal(SIGINT, tratamento_sinal);
	

	while(1){

		system("./att.sh");
		
		if(fd = open("/home/pi/verificador.txt", O_CREAT | O_RDWR) < 0){
		puts("Erro na abertura do arquivo verificador");
		exit(0);
		}

		if(read(fd, &bff, sizeof(bff)) < 0){
			puts("erro na leitura do arquivo verificador.txt");
		}
		
			printf("%s\n", bff);
			sleep(1);

		if(!strcmp(bff, "pac.tar")){
			system("./descomp.sh");
		}
		
		close(fd);
	
	}


return 0;
}
