#!/bin/bash

echo verificando se pac esta na pasta 
echo 
ls /home/pi | grep pac.tar > /home/pi/verificador.txt
echo verificador att
echo
